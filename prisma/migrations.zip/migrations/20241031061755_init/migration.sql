/*
  Warnings:

  - You are about to drop the column `ownerId` on the `grup` table. All the data in the column will be lost.
  - Added the required column `created_by` to the `Grup` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE `grup` DROP FOREIGN KEY `Grup_ownerId_fkey`;

-- AlterTable
ALTER TABLE `grup` DROP COLUMN `ownerId`,
    ADD COLUMN `created_by` VARCHAR(36) NOT NULL;
