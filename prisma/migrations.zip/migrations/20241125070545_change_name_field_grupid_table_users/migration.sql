/*
  Warnings:

  - You are about to drop the column `grupGrupid` on the `users` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `users` DROP COLUMN `grupGrupid`,
    ADD COLUMN `grupid` VARCHAR(36) NULL;
