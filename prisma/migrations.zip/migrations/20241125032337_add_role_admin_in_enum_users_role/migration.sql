-- AlterTable
ALTER TABLE `users` MODIFY `role` ENUM('user', 'ustadz', 'admin') NULL DEFAULT 'user';

-- AlterTable
ALTER TABLE `usersgoogle` MODIFY `role` ENUM('user', 'ustadz', 'admin') NULL DEFAULT 'user';
