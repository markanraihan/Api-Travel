-- DropForeignKey
ALTER TABLE `users` DROP FOREIGN KEY `Users_grupGrupid_fkey`;

-- AddForeignKey
ALTER TABLE `Grup` ADD CONSTRAINT `Grup_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `Users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
