-- DropForeignKey
ALTER TABLE `grup` DROP FOREIGN KEY `Grup_userId_fkey`;

-- AlterTable
ALTER TABLE `users` ADD COLUMN `grupGrupid` VARCHAR(36) NULL,
    ADD COLUMN `status_login` BOOLEAN NOT NULL DEFAULT false;

-- AddForeignKey
ALTER TABLE `Users` ADD CONSTRAINT `Users_grupGrupid_fkey` FOREIGN KEY (`grupGrupid`) REFERENCES `Grup`(`grupid`) ON DELETE SET NULL ON UPDATE CASCADE;
