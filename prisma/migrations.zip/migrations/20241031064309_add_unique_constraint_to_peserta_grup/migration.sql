/*
  Warnings:

  - A unique constraint covering the columns `[grupid,userId]` on the table `Peserta_Grup` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateIndex
CREATE UNIQUE INDEX `Peserta_Grup_grupid_userId_key` ON `Peserta_Grup`(`grupid`, `userId`);
