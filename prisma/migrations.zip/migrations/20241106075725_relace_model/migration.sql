-- DropForeignKey
ALTER TABLE `grup` DROP FOREIGN KEY `Grup_id_room_fkey`;

-- DropIndex
DROP INDEX `Users_grupGrupid_fkey` ON `users`;

-- AddForeignKey
ALTER TABLE `Room` ADD CONSTRAINT `Room_grupid_fkey` FOREIGN KEY (`grupid`) REFERENCES `Grup`(`grupid`) ON DELETE RESTRICT ON UPDATE CASCADE;
