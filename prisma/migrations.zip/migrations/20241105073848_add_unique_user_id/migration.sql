/*
  Warnings:

  - Added the required column `grupid` to the `Room` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE `room` ADD COLUMN `capacity` INTEGER NOT NULL DEFAULT 20,
    ADD COLUMN `grupid` VARCHAR(36) NOT NULL;
