-- AlterTable
ALTER TABLE `profiles` MODIFY `whatsapp` VARCHAR(191) NOT NULL;
