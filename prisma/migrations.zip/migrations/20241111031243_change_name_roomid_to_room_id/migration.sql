/*
  Warnings:

  - You are about to drop the column `roomid` on the `peserta_grup` table. All the data in the column will be lost.
  - The primary key for the `room` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `roomid` on the `room` table. All the data in the column will be lost.
  - The required column `room_id` was added to the `Room` table with a prisma-level default value. This is not possible if the table is not empty. Please add this column as optional, then populate it before making it required.

*/
-- DropForeignKey
ALTER TABLE `peserta_grup` DROP FOREIGN KEY `Peserta_Grup_grupid_fkey`;

-- DropForeignKey
ALTER TABLE `peserta_grup` DROP FOREIGN KEY `Peserta_Grup_roomid_fkey`;

-- AlterTable
ALTER TABLE `peserta_grup` DROP COLUMN `roomid`,
    ADD COLUMN `room_id` VARCHAR(36) NULL;

-- AlterTable
ALTER TABLE `room` DROP PRIMARY KEY,
    DROP COLUMN `roomid`,
    ADD COLUMN `room_id` VARCHAR(36) NOT NULL,
    ADD PRIMARY KEY (`room_id`);

-- CreateTable
CREATE TABLE `_GrupToPeserta_Grup` (
    `A` VARCHAR(36) NOT NULL,
    `B` VARCHAR(36) NOT NULL,

    UNIQUE INDEX `_GrupToPeserta_Grup_AB_unique`(`A`, `B`),
    INDEX `_GrupToPeserta_Grup_B_index`(`B`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `Peserta_Grup` ADD CONSTRAINT `Peserta_Grup_room_id_fkey` FOREIGN KEY (`room_id`) REFERENCES `Room`(`room_id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `_GrupToPeserta_Grup` ADD CONSTRAINT `_GrupToPeserta_Grup_A_fkey` FOREIGN KEY (`A`) REFERENCES `Grup`(`grupid`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `_GrupToPeserta_Grup` ADD CONSTRAINT `_GrupToPeserta_Grup_B_fkey` FOREIGN KEY (`B`) REFERENCES `Peserta_Grup`(`peserta_grupid`) ON DELETE CASCADE ON UPDATE CASCADE;
