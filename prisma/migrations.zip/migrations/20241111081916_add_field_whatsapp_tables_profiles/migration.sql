/*
  Warnings:

  - Added the required column `whatsapp` to the `Profiles` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE `profiles` ADD COLUMN `whatsapp` VARCHAR(35) NOT NULL;
