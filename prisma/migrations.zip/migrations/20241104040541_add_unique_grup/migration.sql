/*
  Warnings:

  - The primary key for the `room` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `id_room` on the `room` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[userId]` on the table `Grup` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `userId` to the `Grup` table without a default value. This is not possible if the table is not empty.
  - The required column `roomid` was added to the `Room` table with a prisma-level default value. This is not possible if the table is not empty. Please add this column as optional, then populate it before making it required.
  - Added the required column `token_listener` to the `Room` table without a default value. This is not possible if the table is not empty.
  - Added the required column `token_moderator` to the `Room` table without a default value. This is not possible if the table is not empty.
  - Added the required column `token_speaker` to the `Room` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE `grup` DROP FOREIGN KEY `Grup_id_room_fkey`;

-- AlterTable
ALTER TABLE `grup` ADD COLUMN `userId` VARCHAR(36) NOT NULL;

-- AlterTable
ALTER TABLE `room` DROP PRIMARY KEY,
    DROP COLUMN `id_room`,
    ADD COLUMN `roomid` VARCHAR(36) NOT NULL,
    ADD COLUMN `token_listener` VARCHAR(191) NOT NULL,
    ADD COLUMN `token_moderator` VARCHAR(191) NOT NULL,
    ADD COLUMN `token_speaker` VARCHAR(191) NOT NULL,
    ADD PRIMARY KEY (`roomid`);

-- CreateIndex
CREATE UNIQUE INDEX `Grup_userId_key` ON `Grup`(`userId`);

-- AddForeignKey
ALTER TABLE `Grup` ADD CONSTRAINT `Grup_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `Users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Grup` ADD CONSTRAINT `Grup_id_room_fkey` FOREIGN KEY (`id_room`) REFERENCES `Room`(`roomid`) ON DELETE SET NULL ON UPDATE CASCADE;
