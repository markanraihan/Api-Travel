/*
  Warnings:

  - You are about to drop the column `room_id` on the `peserta_grup` table. All the data in the column will be lost.
  - The primary key for the `room` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `room_id` on the `room` table. All the data in the column will be lost.
  - The required column `roomid` was added to the `Room` table with a prisma-level default value. This is not possible if the table is not empty. Please add this column as optional, then populate it before making it required.

*/
-- DropForeignKey
ALTER TABLE `peserta_grup` DROP FOREIGN KEY `Peserta_Grup_room_id_fkey`;

-- AlterTable
ALTER TABLE `peserta_grup` DROP COLUMN `room_id`,
    ADD COLUMN `roomid` VARCHAR(36) NULL;

-- AlterTable
ALTER TABLE `room` DROP PRIMARY KEY,
    DROP COLUMN `room_id`,
    ADD COLUMN `roomid` VARCHAR(36) NOT NULL,
    ADD PRIMARY KEY (`roomid`);

-- AddForeignKey
ALTER TABLE `Peserta_Grup` ADD CONSTRAINT `Peserta_Grup_roomid_fkey` FOREIGN KEY (`roomid`) REFERENCES `Room`(`roomid`) ON DELETE SET NULL ON UPDATE CASCADE;
