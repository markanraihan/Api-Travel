-- AlterTable
ALTER TABLE `peserta_grup` ADD COLUMN `usersGoogleId` VARCHAR(36) NULL;

-- AlterTable
ALTER TABLE `progress_perjalanan` ADD COLUMN `usersGoogleId` VARCHAR(36) NULL;

-- CreateTable
CREATE TABLE `UsersGoogle` (
    `id` VARCHAR(36) NOT NULL,
    `name` VARCHAR(255) NOT NULL,
    `email` VARCHAR(255) NOT NULL,
    `whatsapp` VARCHAR(255) NOT NULL,
    `role` ENUM('user', 'ustadz') NULL DEFAULT 'user',
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updatedAt` DATETIME(3) NOT NULL,
    `lastLogin` DATETIME(3) NULL,
    `status_login` BOOLEAN NOT NULL DEFAULT false,
    `grupGrupid` VARCHAR(36) NULL,
    `profilesProfileid` VARCHAR(36) NULL,

    UNIQUE INDEX `UsersGoogle_name_key`(`name`),
    UNIQUE INDEX `UsersGoogle_email_key`(`email`),
    UNIQUE INDEX `UsersGoogle_whatsapp_key`(`whatsapp`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `Peserta_Grup` ADD CONSTRAINT `Peserta_Grup_usersGoogleId_fkey` FOREIGN KEY (`usersGoogleId`) REFERENCES `UsersGoogle`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Progress_perjalanan` ADD CONSTRAINT `Progress_perjalanan_usersGoogleId_fkey` FOREIGN KEY (`usersGoogleId`) REFERENCES `UsersGoogle`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `UsersGoogle` ADD CONSTRAINT `UsersGoogle_profilesProfileid_fkey` FOREIGN KEY (`profilesProfileid`) REFERENCES `Profiles`(`profileid`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `UsersGoogle` ADD CONSTRAINT `UsersGoogle_grupGrupid_fkey` FOREIGN KEY (`grupGrupid`) REFERENCES `Grup`(`grupid`) ON DELETE SET NULL ON UPDATE CASCADE;
