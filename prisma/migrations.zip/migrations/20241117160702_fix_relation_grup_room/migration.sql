/*
  Warnings:

  - You are about to drop the column `grupid` on the `room` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[roomid]` on the table `Grup` will be added. If there are existing duplicate values, this will fail.

*/
-- DropForeignKey
ALTER TABLE `room` DROP FOREIGN KEY `Room_grupid_fkey`;

-- AlterTable
ALTER TABLE `grup` ADD COLUMN `roomid` VARCHAR(191) NULL;

-- AlterTable
ALTER TABLE `room` DROP COLUMN `grupid`;

-- CreateIndex
CREATE UNIQUE INDEX `Grup_roomid_key` ON `Grup`(`roomid`);

-- AddForeignKey
ALTER TABLE `Grup` ADD CONSTRAINT `Grup_roomid_fkey` FOREIGN KEY (`roomid`) REFERENCES `Room`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
