/*
  Warnings:

  - The values [Pembimbing] on the enum `Users_role` will be removed. If these variants are still used in the database, this will fail.

*/
-- AlterTable
ALTER TABLE `users` ADD COLUMN `lastLogin` DATETIME(3) NULL,
    MODIFY `role` ENUM('user', 'ustadz') NULL DEFAULT 'user';

-- CreateTable
CREATE TABLE `Grup` (
    `grupid` VARCHAR(36) NOT NULL,
    `nama_grup` VARCHAR(36) NOT NULL,
    `ownerId` VARCHAR(36) NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `finish_at` DATETIME(3) NULL,
    `open_user` INTEGER NOT NULL,
    `id_room` VARCHAR(36) NULL,
    `status` VARCHAR(50) NOT NULL,

    PRIMARY KEY (`grupid`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Peserta_Grup` (
    `peserta_grupid` VARCHAR(36) NOT NULL,
    `grupid` VARCHAR(36) NOT NULL,
    `userId` VARCHAR(36) NOT NULL,
    `joinedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `online` VARCHAR(10) NOT NULL,

    PRIMARY KEY (`peserta_grupid`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Progress` (
    `progressid` VARCHAR(36) NOT NULL,
    `grupid` VARCHAR(36) NOT NULL,
    `jenis_perjalanan` VARCHAR(20) NOT NULL,
    `live` INTEGER NOT NULL,
    `status` BOOLEAN NOT NULL,

    PRIMARY KEY (`progressid`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Progress_perjalanan` (
    `progress_perjalananid` VARCHAR(36) NOT NULL,
    `progressid` VARCHAR(36) NOT NULL,
    `userId` VARCHAR(36) NOT NULL,
    `perjalananid` VARCHAR(36) NOT NULL,
    `waktu_mulai` DATETIME(3) NOT NULL,
    `time_selesai` DATETIME(3) NULL,

    PRIMARY KEY (`progress_perjalananid`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Perjalanan` (
    `perjalananid` VARCHAR(36) NOT NULL,
    `nama_perjalanan` VARCHAR(100) NOT NULL,

    PRIMARY KEY (`perjalananid`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Room` (
    `id_room` VARCHAR(36) NOT NULL,
    `nama_room` VARCHAR(100) NOT NULL,

    PRIMARY KEY (`id_room`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `Grup` ADD CONSTRAINT `Grup_ownerId_fkey` FOREIGN KEY (`ownerId`) REFERENCES `Users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Grup` ADD CONSTRAINT `Grup_id_room_fkey` FOREIGN KEY (`id_room`) REFERENCES `Room`(`id_room`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Peserta_Grup` ADD CONSTRAINT `Peserta_Grup_grupid_fkey` FOREIGN KEY (`grupid`) REFERENCES `Grup`(`grupid`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Peserta_Grup` ADD CONSTRAINT `Peserta_Grup_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `Users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Progress` ADD CONSTRAINT `Progress_grupid_fkey` FOREIGN KEY (`grupid`) REFERENCES `Grup`(`grupid`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Progress_perjalanan` ADD CONSTRAINT `Progress_perjalanan_progressid_fkey` FOREIGN KEY (`progressid`) REFERENCES `Progress`(`progressid`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Progress_perjalanan` ADD CONSTRAINT `Progress_perjalanan_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `Users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Progress_perjalanan` ADD CONSTRAINT `Progress_perjalanan_perjalananid_fkey` FOREIGN KEY (`perjalananid`) REFERENCES `Perjalanan`(`perjalananid`) ON DELETE RESTRICT ON UPDATE CASCADE;
