-- DropIndex
DROP INDEX `Grup_id_room_fkey` ON `grup`;

-- AlterTable
ALTER TABLE `peserta_grup` ADD COLUMN `roomid` VARCHAR(36) NULL;

-- AddForeignKey
ALTER TABLE `Peserta_Grup` ADD CONSTRAINT `Peserta_Grup_roomid_fkey` FOREIGN KEY (`roomid`) REFERENCES `Room`(`roomid`) ON DELETE SET NULL ON UPDATE CASCADE;
