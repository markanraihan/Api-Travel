-- CreateIndex
CREATE INDEX `Grup_userId_idx` ON `Grup`(`userId`);
