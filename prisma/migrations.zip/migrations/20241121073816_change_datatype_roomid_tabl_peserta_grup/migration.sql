/*
  Warnings:

  - A unique constraint covering the columns `[roomid]` on the table `Peserta_Grup` will be added. If there are existing duplicate values, this will fail.

*/
-- DropForeignKey
ALTER TABLE `peserta_grup` DROP FOREIGN KEY `Peserta_Grup_roomid_fkey`;

-- AlterTable
ALTER TABLE `peserta_grup` MODIFY `roomid` VARCHAR(191) NULL;

-- CreateIndex
CREATE UNIQUE INDEX `Peserta_Grup_roomid_key` ON `Peserta_Grup`(`roomid`);

-- AddForeignKey
ALTER TABLE `Peserta_Grup` ADD CONSTRAINT `Peserta_Grup_roomid_fkey` FOREIGN KEY (`roomid`) REFERENCES `Room`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
