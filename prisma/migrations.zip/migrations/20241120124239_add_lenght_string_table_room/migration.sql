-- AlterTable
ALTER TABLE `room` MODIFY `token_listener` VARCHAR(1000) NOT NULL,
    MODIFY `token_speaker` VARCHAR(1000) NOT NULL;
